using UnityEngine;

public interface IDamageable
{
    void TakeDamage(int amount);
}

public class Hurtbox : MonoBehaviour
{
    [SerializeField] private Component healthReceiver; // опционально проставь вручную (скрипт со здоровьем)

    public void ApplyHit(int damage, Vector3 hitPoint)
    {
        if (healthReceiver != null)
        {
            // Интерфейс?
            if (healthReceiver is IDamageable idmg)
            {
                idmg.TakeDamage(damage);
                return;
            }
            // Популярные кейсы
            var mh = healthReceiver as MonoBehaviour;
            if (mh != null)
            {
                var recv = mh.GetComponent<IDamageable>();
                if (recv != null) { recv.TakeDamage(damage); return; }
            }
        }

        // Автопоиск по объекту
        var any = GetComponentInParent<IDamageable>();
        if (any != null) { any.TakeDamage(damage); return; }

        // Самые распространенные имена
        var eh = GetComponentInParent(typeof(Component).Assembly.GetType("EnemyHealth")) as Component;
        if (eh != null)
        {
            eh.SendMessage("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);
            return;
        }

        var h = GetComponentInParent(typeof(Component).Assembly.GetType("Health")) as Component;
        if (h != null)
        {
            h.SendMessage("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);
            return;
        }

        // Фоллбек
        SendMessageUpwards("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);
    }
}
