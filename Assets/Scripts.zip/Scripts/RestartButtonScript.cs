using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class RestartManager : MonoBehaviour
{
    public Button restartButton;
    private InputAction restartAction;

    void OnEnable()
    {
        restartAction = new InputAction(binding: "<Keyboard>/r");
        restartAction.performed += ctx => Restart();
        restartAction.Enable();
    }

    void OnDisable()
    {
        restartAction.Disable();
    }

    void Start()
    {
        if (restartButton != null)
            restartButton.onClick.AddListener(Restart);
    }

    void Restart()
    {
        CursorLocker.playerIsAlive = true;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
