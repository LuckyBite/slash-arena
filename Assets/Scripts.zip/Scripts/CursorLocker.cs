using UnityEngine;
using UnityEngine.InputSystem;

public class CursorLocker : MonoBehaviour
{
    public static bool playerIsAlive = true;

    private InputAction leftClickAction;
    private InputAction escKeyAction;

    void OnEnable()
    {
        leftClickAction = new InputAction(type: InputActionType.Button, binding: "<Mouse>/leftButton");
        escKeyAction = new InputAction(type: InputActionType.Button, binding: "<Keyboard>/escape");

        leftClickAction.performed += ctx => TryLock();
        escKeyAction.performed += ctx => UnlockCursor();

        leftClickAction.Enable();
        escKeyAction.Enable();
    }

    void OnDisable()
    {
        leftClickAction.Disable();
        escKeyAction.Disable();
    }

    void TryLock()
    {
        if (playerIsAlive && Cursor.lockState != CursorLockMode.Locked)
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
    }

    public static void UnlockCursor()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
}
