using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class EnemyAttack : MonoBehaviour
{
    public int damage = 10;
    public float attackInterval = 1.5f;
    Transform player;
    float timer;

    void Start() => player = GameObject.FindWithTag("Player").transform;

    void Update()
    {
        if (player == null) return;

        timer += Time.deltaTime;
        if (timer >= attackInterval)
        {
            timer = 0f;
            player.GetComponent<PlayerHealth>()?.TakeDamage(damage);
        }
    }
}
